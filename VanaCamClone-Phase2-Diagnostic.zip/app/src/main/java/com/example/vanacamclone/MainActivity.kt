package com.example.vanacamclone

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import android.companion.virtual.VirtualDeviceManager

class MainActivity : AppCompatActivity() {
    private lateinit var player: ExoPlayer
    private lateinit var status: TextView
    private lateinit var info: TextView
    private var loop = false

    private val pickVideo = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            player.setMediaItem(MediaItem.fromUri(uri))
            player.prepare()
            player.play()
            info.text = "Video siap dipakai sebagai sumber frame pada engine berikutnya."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        status = findViewById(R.id.status)
        info = findViewById(R.id.info)
        val playerView: PlayerView = findViewById(R.id.player)
        val pick: Button = findViewById(R.id.pickVideo)
        val activate: Button = findViewById(R.id.activate)
        val loopButton: Button = findViewById(R.id.loop)

        player = ExoPlayer.Builder(this).build()
        playerView.player = player

        player.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_ENDED && loop) {
                    player.seekTo(0)
                    player.play()
                }
            }
        })

        pick.setOnClickListener { pickVideo.launch("video/*") }

        loopButton.setOnClickListener {
            loop = !loop
            loopButton.text = if (loop) "LOOP: ON" else "LOOP: OFF"
        }

        activate.setOnClickListener { runCapabilityTest() }

        runCapabilityTest()
    }

    private fun runCapabilityTest() {
        val report = StringBuilder()

        report.append("DEVICE\n")
        report.append("Model: ${Build.MANUFACTURER} ${Build.MODEL}\n")
        report.append("Android: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n\n")

        val vdm = getSystemService(Context.VIRTUAL_DEVICE_SERVICE) as? VirtualDeviceManager
        report.append("VIRTUAL DEVICE\n")
        if (vdm == null) {
            report.append("VirtualDeviceManager: NOT EXPOSED\n")
            report.append("Virtual camera jalur AOSP tidak dapat dipakai dari aplikasi biasa pada perangkat ini.\n\n")
        } else {
            report.append("VirtualDeviceManager: AVAILABLE\n")
            report.append("Virtual devices: ${vdm.virtualDevices.size}\n")
            report.append("Catatan: API publik ini sendiri tidak memberi izin kepada APK biasa untuk membuat virtual camera host.\n\n")
        }

        report.append("CAMERA2\n")
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            report.append("Permission kamera belum diberikan.\n")
        } else {
            val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            try {
                for (id in cm.cameraIdList) {
                    val c = cm.getCameraCharacteristics(id)
                    val facing = c.get(CameraCharacteristics.LENS_FACING)
                    val facingText = when (facing) {
                        CameraCharacteristics.LENS_FACING_FRONT -> "FRONT"
                        CameraCharacteristics.LENS_FACING_BACK -> "BACK"
                        CameraCharacteristics.LENS_FACING_EXTERNAL -> "EXTERNAL"
                        else -> "UNKNOWN"
                    }
                    report.append("Camera $id: $facingText\n")
                }
            } catch (e: Exception) {
                report.append("Camera query error: ${e.javaClass.simpleName}\n")
            }
        }

        status.text = if (vdm != null) {
            "● PLATFORM: VIRTUAL DEVICE API TERSEDIA"
        } else {
            "● PLATFORM: VIRTUAL DEVICE API TIDAK TERSEDIA"
        }
        status.setTextColor(0xFFFFD54F.toInt())
        info.text = report.toString()
    }

    override fun onDestroy() {
        player.release()
        super.onDestroy()
    }
}
